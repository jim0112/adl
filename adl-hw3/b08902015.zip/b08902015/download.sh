wget https://www.dropbox.com/s/0ztylhiom882br7/checkpoint-27140.zip?dl=1 --content-disposition
unzip checkpoint-27140.zip